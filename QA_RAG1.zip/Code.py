import os
 
import streamlit as st
import pdfkit
import os
import logging
import faiss
import numpy as np
from flask import Flask, render_template, request, redirect, send_file, session
from PyPDF2 import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter
import google.generativeai as genai
from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI
from langchain_community.vectorstores import FAISS
from langchain.memory import ConversationBufferMemory
from langchain.chains.conversational_retrieval.base import ConversationalRetrievalChain
from dotenv import load_dotenv
from jinja2 import Template
load_dotenv()
os.environ["GOOGLE_API_KEY"]=os.getenv("GOOGLE_API_KEY")
# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24)  # Secure session
model = genai.GenerativeModel(model_name='gemini-1.5-flash-002')
 


# Helper function to traverse directories and collect code files
def traverse_repo(root_dir):
    file_data = {"asp": [], "dotnet": [], "database": []}
    for root, dirs, files in os.walk(root_dir):
        for file in files:
            if file.endswith(".aspx"):
                with open(os.path.join(root, file), "r", encoding='utf-8', errors='ignore') as f:
                    file_data["asp"].append(f.read())
            elif file.endswith(".cs"):  # .NET code
                with open(os.path.join(root, file), "r", encoding='utf-8', errors='ignore') as f:
                    file_data["dotnet"].append(f.read())
            elif file.endswith(".sql"):  # SQL database procedures
                with open(os.path.join(root, file), "r", encoding='utf-8', errors='ignore') as f:
                    file_data["database"].append(f.read())
    return file_data

# Helper function to call OpenAI's GPT model for generating business requirements
def analyze_code_and_generate_docs(file_data):
    try:
        # Prepare the content for AI analysis: Combine .NET, ASP, and SQL code
        code_combined = ""
        code_combined += "\n".join(file_data["asp"])  # Add all ASP files content
        code_combined += "\n".join(file_data["dotnet"])  # Add all .NET files content
        code_combined += "\n".join(file_data["database"])  # Add all SQL files content

        # Create a prompt for GPT to understand the transition from monolithic to microservices
        prompt = f"""
        Given the following code from a legacy monolithic system (ASP, .NET, SQL):
        {code_combined}
        
        The task is to move this monolithic system to a microservices-based architecture.
        Please generate a Business Requirement Document (BRD) outlining the necessary changes, 
        including the transition to Java for backend services, MFF (Micro Frontend Framework), 
        BFF (Backend for Frontend), DynamoDB for database storage, and GraphQL for data access.
        The document should include high-level requirements, major system changes, and relevant details.
        """

        # Requesting GPT-3/4 model to generate the BRD
        response = model.generate_content(prompt)
            

        # Get the generated text from the response
        business_requirements = response.choices[0].text.strip()

        return business_requirements

    except Exception as e:
        return f"An error occurred: {e}"

# Function to create a PDF
def create_pdf(business_requirements):
    pdf_content = f"""
    Business Requirements Document
    
    The following changes are required for the transition from Monolithic to Microservices:
    
    {business_requirements}
    
    Microservices Architecture will be implemented with the following:
    - Java for Backend Logic
    - MFF (Micro Frontend Framework)
    - BFF (Backend For Frontend)
    - DynamoDB for Database
    - GraphQL for Data Access
    """
    
    pdf = pdfkit.from_string(pdf_content, False)  # Generate PDF from string content
    return pdf

# Streamlit Interface
st.title("Generative AI Business Requirements Generator")

# Allow user to select the root directory
root_dir = st.text_input("Enter the path to the root repository folder:", "")

if st.button("Generate Business Requirement Document"):
    if root_dir and os.path.isdir(root_dir):
        st.write("Traversing repository...")

        # Traverse the repository to get code data
        file_data = traverse_repo(root_dir)

        # Show the number of files found in each category
        st.write(f"Found {len(file_data['asp'])} ASP files.")
        st.write(f"Found {len(file_data['dotnet'])} .NET files.")
        st.write(f"Found {len(file_data['database'])} SQL database files.")

        # Generate business requirement document
        st.write("Generating business requirement document...")
        business_requirements = analyze_code_and_generate_docs(file_data)

        # Show business requirements
        st.subheader("Business Requirement Document:")
        st.write(business_requirements)

        # Generate PDF
        pdf = create_pdf(business_requirements)

        # Provide a download link for the generated PDF
        st.download_button(
            label="Download PDF",
            data=pdf,
            file_name="business_requirements_document.pdf",
            mime="application/pdf"
        )
    else:
        st.error("Please provide a valid directory path.")
