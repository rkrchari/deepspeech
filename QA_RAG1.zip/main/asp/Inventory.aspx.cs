using System;
using System.Web.UI;
using System.Collections.Generic;

namespace InventoryApp
{
    public partial class Inventory : Page
    {
        private InventoryService inventoryService = new InventoryService();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindInventoryData();
            }
        }

        private void BindInventoryData()
        {
            GridView1.DataSource = inventoryService.GetItems();
            GridView1.DataBind();
        }
    }
}
