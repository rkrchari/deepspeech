-- Create Inventory Table
CREATE TABLE Inventory (
    ItemId INT PRIMARY KEY,
    Name VARCHAR(100),
    Quantity INT,
    Price DECIMAL(10, 2)
);

-- Sample stored procedure to add an inventory item
CREATE PROCEDURE AddInventoryItem
    @ItemId INT,
    @Name VARCHAR(100),
    @Quantity INT,
    @Price DECIMAL(10, 2)
AS
BEGIN
    INSERT INTO Inventory (ItemId, Name, Quantity, Price)
    VALUES (@ItemId, @Name, @Quantity, @Price);
END;

-- Sample stored procedure to update an inventory item
CREATE PROCEDURE UpdateInventoryItem
    @ItemId INT,
    @Name VARCHAR(100),
    @Quantity INT,
    @Price DECIMAL(10, 2)
AS
BEGIN
    UPDATE Inventory
    SET Name = @Name, Quantity = @Quantity, Price = @Price
    WHERE ItemId = @ItemId;
END;

-- Sample stored procedure to retrieve all inventory items
CREATE PROCEDURE GetAllInventoryItems
AS
BEGIN
    SELECT * FROM Inventory;
END;
